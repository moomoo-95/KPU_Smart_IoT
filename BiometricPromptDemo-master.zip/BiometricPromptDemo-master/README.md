# BiometricPromptDemo
Android fingerprint, Api23 and Api28 are supported

介绍文档请参阅：https://www.jianshu.com/p/1eae12582a31

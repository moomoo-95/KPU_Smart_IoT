#ifndef __sntp_lwip2_h__
#define __sntp_lwip2_h__

#include <coredecls.h>

#endif
